"""
This module contains experimental code that may go into scrapy.contrib in the
future, but it's not yet stable enough to go there (either API stable or
functionality stable).

Subscribe to Scrapy developers mailing list or join the IRC channel if you want
to discuss about this code.

"""
